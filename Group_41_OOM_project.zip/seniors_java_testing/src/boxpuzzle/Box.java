package boxpuzzle;

import java.awt.Color;
import java.awt.Font;

import javax.swing.*;


public class Box extends JButton{
    private int positionX;
//  public JButton vin;
    private int positionY;
    private String theme;
    protected int getPositionX() {
        return positionX;
    }

    protected int getPositionY() {
        return positionY;
    }


    // used to replace the box position
    Box(int positionX, int positionY, int num, String theme) {
        this.setText(String.valueOf(num));			// string to int then pass the value
        //vin.setText(String.valueOf(num));
        System.out.println(this.getText());
        this.theme = theme;
        this.positionX = positionX;
        this.positionY = positionY;
        Color colorBack;
        Color colorFront;
        MyBorder border = new MyBorder(theme);

        Theme t = new Theme(theme);
        colorBack = t.colorBack;
        colorFront = t.colorFront;

        setFont(new Font("Tahoma", Font.BOLD, 100));
//        vin.setFont()
//        setForeground(Color.red);
        setFocusable(false);
    }
}