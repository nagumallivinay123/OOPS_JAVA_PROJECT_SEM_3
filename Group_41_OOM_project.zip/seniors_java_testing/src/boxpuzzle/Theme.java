package boxpuzzle;

import java.awt.Color;

public class Theme {
    Color colorBack;
    Color colorFront;

    Theme(String theme) {
        if (theme == "Dark") {
            colorFront= new Color(255, 36, 0);
            colorBack = new Color(0,18,83);


        }
        else {
            colorBack = new Color(51, 51, 51);
            colorFront = new Color(250, 200, 200);
        }
    }
}